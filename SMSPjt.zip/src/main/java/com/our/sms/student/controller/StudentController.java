package com.our.sms.student.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.our.sms.student.service.StudentService;
import com.our.sms.student.vo.StudentVo;

@Controller
public class StudentController { 
	
	// service 객체 생성을 자동화해줌 
	@Autowired
	StudentService studentService;
	
	/*
	홈
	*/
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String index() {
		System.out.println("index INIT!");
		
		return "index";
	}
	
	/*
	학생 목록
	*/
	
	@RequestMapping(value = "/stdList", method = RequestMethod.GET)
	public String studentList(Model model) {
		System.out.println("studentList() INIT!");
		
		ArrayList<StudentVo> studentVos = studentService.getStudentVos();
		model.addAttribute("studentVos", studentVos);
	
		return "stdList";
	}
	
	/*
	학생 등록 폼 
	*/
	
	@RequestMapping(value = "/stdAdd", method = RequestMethod.GET)
	public String studentAdd() {
		System.out.println("studentAdd() INIT!");
		
		return "stdAddForm";
	}
	
	/*
	학생 DB 등록
	*/
	// 학생 정보가 있으므로 POST 방식!
	@RequestMapping(value = "/stdAddConfirm", method = RequestMethod.POST)
	public String studentAddConfirm(HttpServletRequest request, Model model) {
		System.out.println("studentAddConfirm() INIT!");
		
		StudentVo studentVo = new StudentVo();
		
		int result = studentService.addStudent(studentVo);
		model.addAttribute("result", result);  // 결과를 jsp로 보냄 
		
		// 바로 list로 가지않고 업데이트 필요함
		return "redirect:/stdList";
	}
	
	
	/*
	학생 정보 수정 폼
	*/
	
	@RequestMapping(value = "/stdModify", method = RequestMethod.GET)
	public String studentModify() {
		System.out.println("studentModify() INIT!");
		
		return "stdModify";
	}
	
	/*
	학생 DB 정보 수정
	*/
	
	@RequestMapping(value = "/stdModifyConfirm", method = RequestMethod.POST)
	public String studentModifyConfirm(HttpServletRequest request, Model model) {
		System.out.println("studentModifyConfirm() INIT!");
		
		StudentVo studentVo = new StudentVo();
		int result = studentService.modifyStudentVo(studentVo);
		model.addAttribute("result", result);
		
		return "redirect:/stdList";
	}
	
	/*
	학생 정보 삭제
	*/
	
	@RequestMapping(value = "/stdDelete", method = RequestMethod.GET)
	public String studentDelete() {
		
		return null;
	}
	
	
}
