package com.our.sms.student.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.our.sms.student.dao.StudentDao;
import com.our.sms.student.vo.StudentVo;

@Service
public class StudentService {
	
	// Dao 객체를 자동화로 불러와줌
	@Autowired
	StudentDao studentDao;

	public List<StudentVo> getStudentVos() {
		
		System.out.println("[StudentService] getStudentVos() INIT!");
		
		List<StudentVo> studentVos = studentDao.selectStudentVos();
		
		return studentVos;  
	}

	public int addStudent(StudentVo studentVo) {
		
		System.out.println("[StudentService] addStudent() INIT!");
		
		int result = studentDao.insertStudentVo(studentVo);
		
		return result;
	}

	public int modifyStudentVo(StudentVo studentVo) {
		
		System.out.println("[StudentService] modifyStudentVo() INIT!");
		
		int result = studentDao.modifyStudentVo(studentVo);
		
		return result;
	}

	public int deleteStudentVo(StudentVo studentVo) {
		
		System.out.println("[StudentService] deleteStudentVo() INIT!");
		
		int result = studentDao.deleteStudentVo(studentVo);
		
		return result;
	}

	public StudentVo getStudentVo(int s_no) {

		System.out.println("[StudentService] getStudentVo() INIT!");
		
		StudentVo studentVo = studentDao.selectStudentVo(s_no);
		
		return studentVo;
	}
}
