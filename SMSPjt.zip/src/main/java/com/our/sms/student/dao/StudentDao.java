package com.our.sms.student.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Component;

import com.our.sms.student.vo.StudentVo;

@Component
public class StudentDao {

	public ArrayList<StudentVo> selectStudentVos() {
		
		System.out.println("[StudentDao] selectStudentVos() INIT!");
		
		ArrayList<StudentVo> studentVos = new ArrayList<StudentVo>();
		
		
		return studentVos;
	}

	public int insertStudentVo(StudentVo studentVo) {
		
		System.out.println("[StudentDao] insertStudentVo() INIT!");
		
		int result = 0;
		
		return result;
	}

}
