package com.our.sms.student.vo;

public class StudentVo {

}
